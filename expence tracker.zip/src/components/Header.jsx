import React from "react";
 const Header=()=>{
    return (
        <>
        
          <h2>Expense Tracker</h2>
     
        </>
    )
 }
 export default Header 